(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_46d16782._.js",
  "static/chunks/node_modules_zod_v4_05d335f2._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_996205a8._.js",
  "static/chunks/_abb9c763._.js"
],
    source: "dynamic"
});
