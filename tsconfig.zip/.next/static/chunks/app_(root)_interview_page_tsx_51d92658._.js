(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_zod_v4_6eafb722._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_@daily-co_daily-js_dist_daily-esm_97c9621b.js",
  "static/chunks/node_modules_@vapi-ai_web_dist_98fc99c2._.js",
  "static/chunks/node_modules_c7e9c83b._.js",
  "static/chunks/_707e6974._.js"
],
    source: "dynamic"
});
