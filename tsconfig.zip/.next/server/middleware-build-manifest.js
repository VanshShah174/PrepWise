globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_82a36480.js",
      "static/chunks/node_modules_next_dist_compiled_ca41998d._.js",
      "static/chunks/node_modules_next_dist_shared_lib_492fcef6._.js",
      "static/chunks/node_modules_next_dist_client_becf32a6._.js",
      "static/chunks/node_modules_next_dist_ad6392d3._.js",
      "static/chunks/node_modules_next_app_95ea274f.js",
      "static/chunks/[next]_entry_page-loader_ts_f9f6e84e._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_f2979c3a._.js",
      "static/chunks/[root-of-the-server]__010dee56._.js",
      "static/chunks/pages__app_5771e187._.js",
      "static/chunks/pages__app_4b3c26ac._.js"
    ],
    "/_error": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_82a36480.js",
      "static/chunks/node_modules_next_dist_compiled_ca41998d._.js",
      "static/chunks/node_modules_next_dist_shared_lib_3cbd5cc2._.js",
      "static/chunks/node_modules_next_dist_client_becf32a6._.js",
      "static/chunks/node_modules_next_dist_7c4b9b2a._.js",
      "static/chunks/node_modules_next_error_8c8bf619.js",
      "static/chunks/[next]_entry_page-loader_ts_8ccf5f86._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_f2979c3a._.js",
      "static/chunks/[root-of-the-server]__95ff7225._.js",
      "static/chunks/pages__error_5771e187._.js",
      "static/chunks/pages__error_50fcf3db._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/node_modules_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_6aaa83c7._.js",
    "static/chunks/node_modules_next_dist_compiled_react-dom_1f56dc06._.js",
    "static/chunks/node_modules_next_dist_compiled_next-devtools_index_d575f738.js",
    "static/chunks/node_modules_next_dist_compiled_0f1b9fd4._.js",
    "static/chunks/node_modules_next_dist_client_20b209c9._.js",
    "static/chunks/node_modules_next_dist_445d8acf._.js",
    "static/chunks/node_modules_@swc_helpers_cjs_8e433861._.js",
    "static/chunks/_e69f0d32._.js",
    "static/chunks/_01f48b92._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];